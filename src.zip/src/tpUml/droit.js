"use strict";
exports.__esModule = true;
exports.Droit = void 0;
var Droit = /** @class */ (function () {
    function Droit() {
        this.idDroit = undefined;
        this.type = undefined;
        this.dateDebut = undefined;
        this.dateFin = undefined;
    }
    return Droit;
}());
exports.Droit = Droit;
