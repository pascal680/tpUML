"use strict";
exports.__esModule = true;
var droit_1 = require("./droit");
var droitProduit_1 = require("./droitProduit");
var droitType_1 = require("./droitType");
var entreprise_1 = require("./entreprise");
var inidividu_1 = require("./inidividu");
var produit_1 = require("./produit");
var faker = require('faker');
var fs = require('fs');
function generateClients() {
    var clients = [];
    for (var id = 1; id <= 5; id++) {
        var individu = new inidividu_1.Individu();
        var entreprise = new entreprise_1.Entreprise();
        var instance = Math.floor((Math.random() * 2) + 1);
        if (instance == 1) {
            individu.idClient = id;
            individu.adresse = faker.address.streetAddress();
            individu.prenom = faker.name.firstName();
            individu.nom = faker.name.lastName();
            individu.email = faker.internet.email();
            individu.details.idDetails = id;
            individu.details.province = faker.address.state();
            individu.details.rue = faker.address.streetName();
            individu.details.ville = faker.address.city();
            clients.push({
                "individu": individu
            });
        }
        else if (instance == 2) {
            entreprise.idClient = id;
            entreprise.adresse = faker.address.streetAddress();
            entreprise.nom = faker.company.companyName();
            entreprise.phone = faker.phone.phoneNumberFormat();
            entreprise.fax = faker.phone.phoneNumberFormat();
            entreprise.details.idDetails = id;
            entreprise.details.province = faker.address.state();
            entreprise.details.rue = faker.address.streetName();
            entreprise.details.ville = faker.address.city();
            entreprise.contact.prenom = faker.name.firstName();
            entreprise.contact.nom = faker.name.lastName();
            entreprise.contact.email = faker.internet.email();
            clients.push({
                "entreprise": entreprise
            });
        }
    }
    return { "data": clients };
}
function generateDroitProduits() {
    var tableauDroitProduits = [];
    for (var id = 1; id <= 5; id++) {
        var droit = new droit_1.Droit();
        var produit = new produit_1.Produit(true);
        var droitProduit = new droitProduit_1.DroitProduit(droit, produit);
        //instancier les attributs de droit
        var instanceDroit = Math.floor((Math.random() * 3) + 1);
        droit.idDroit = id.toString();
        switch (instanceDroit) {
            case 1: {
                droit.type = droitType_1.DroitType.Droit01;
                break;
            }
            case 2: {
                droit.type = droitType_1.DroitType.Droit02;
                break;
            }
            case 3: {
                droit.type = droitType_1.DroitType.Droit03;
                break;
            }
        }
        droit.dateDebut = faker.date.past();
        droit.dateFin = faker.date.future();
        tableauDroitProduits.push({
            "Droit": droit
        });
        //Fin instanciation des attributs de droit
        //Instancier les attribut de produit
        produit.id = id;
        produit.nom = faker.commerce.productName();
        produit.description = faker.company.catchPhrase();
        produit.option.id = id;
        produit.option.nom = faker.commerce.productMaterial();
        produit.option.description = faker.commerce.productAdjective();
        //instancier singleton de produit mais pas a l'infinie.
        produit.produit.id = id + 1000000;
        produit.produit.nom = faker.commerce.productName();
        produit.produit.description = faker.company.catchPhrase();
        produit.produit.option.id = id;
        produit.produit.option.nom = faker.commerce.productMaterial();
        produit.produit.option.description = faker.commerce.productAdjective();
        //produit.produit.produit = null;
        tableauDroitProduits.push({
            "Produit": produit
        });
        //Ajouter l'object droitProduit pour permettre la relation de many to many dans notre structure
        tableauDroitProduits.push({
            "DroitProduit": droitProduit
        });
    }
    return { "data": tableauDroitProduits };
}
var dataGenerate1 = generateClients();
var dataGenerate2 = generateDroitProduits();
fs.writeFileSync('database/data1.json', JSON.stringify(dataGenerate1, null, '\t'));
fs.writeFileSync('database/data2.json', JSON.stringify(dataGenerate2, null, '\t'));
