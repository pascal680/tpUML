"use strict";
exports.__esModule = true;
exports.Produit = void 0;
var option_1 = require("./option");
var Produit = /** @class */ (function () {
    function Produit(instancierSingletonProduit) {
        this.id = undefined;
        this.nom = undefined;
        this.description = undefined;
        this.option = new option_1.Option();
        if (instancierSingletonProduit) {
            //pour eviter d'instancier a l'infini
            this.produit = new Produit(false);
        }
    }
    return Produit;
}());
exports.Produit = Produit;
