export class Option {
    id: number;
    nom: string;
    description: string;

    constructor(){
        this.id = undefined;
        this.nom = undefined;
        this.description = undefined;
    }
}