import { Droit } from "./droit";
import { Produit } from "./produit";

export class DroitProduit {
    droit: Droit;
    produit: Produit;

    constructor(droit: Droit, produit: Produit){
        this.droit = droit;
        this.produit = produit;
    }
}