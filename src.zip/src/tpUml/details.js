"use strict";
exports.__esModule = true;
exports.Details = void 0;
var Details = /** @class */ (function () {
    function Details() {
        this.idDetails = undefined;
        this.rue = undefined;
        this.ville = undefined;
        this.province = undefined;
    }
    return Details;
}());
exports.Details = Details;
