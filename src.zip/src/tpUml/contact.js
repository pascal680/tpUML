"use strict";
exports.__esModule = true;
exports.Contact = void 0;
var Contact = /** @class */ (function () {
    function Contact() {
        this.prenom = undefined;
        this.nom = undefined;
        this.email = undefined;
    }
    return Contact;
}());
exports.Contact = Contact;
