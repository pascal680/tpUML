import { Option } from "./option";

export class Produit {
    id: number;
    nom: string;
    description: string;
    option: Option;
    produit: Produit;
    

    constructor(instancierSingletonProduit: boolean){
        this.id = undefined;
        this.nom = undefined;
        this.description = undefined;
        this.option = new Option();
        if(instancierSingletonProduit){
            //pour eviter d'instancier a l'infini
          this.produit = new Produit(false); 
        }
        
        
    
    }
}