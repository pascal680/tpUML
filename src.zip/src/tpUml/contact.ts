export class Contact {
    prenom: string;
    nom: string;
    email: string;

    constructor(){
        this.prenom = undefined;
        this.nom = undefined;
        this.email = undefined;
    }
}