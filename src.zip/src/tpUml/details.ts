export class Details {
    
    idDetails: number;
    rue: string;
    ville: string;
    province: string;

    constructor(){
        this.idDetails = undefined;
        this.rue = undefined;
        this.ville = undefined;
        this.province = undefined;
    }
}