"use strict";
exports.__esModule = true;
exports.ClientType = void 0;
var ClientType;
(function (ClientType) {
    ClientType["Individu"] = "Individu";
    ClientType["Entreprise"] = "Entreprise";
})(ClientType = exports.ClientType || (exports.ClientType = {}));
