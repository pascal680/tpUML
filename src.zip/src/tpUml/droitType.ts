export enum DroitType {
    Droit01 = "Droit-01",
    Droit02 = "Droit-02",
    Droit03 = "Droit-03"
}