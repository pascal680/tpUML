"use strict";
exports.__esModule = true;
exports.DroitType = void 0;
var DroitType;
(function (DroitType) {
    DroitType["Droit01"] = "Droit-01";
    DroitType["Droit02"] = "Droit-02";
    DroitType["Droit03"] = "Droit-03";
})(DroitType = exports.DroitType || (exports.DroitType = {}));
