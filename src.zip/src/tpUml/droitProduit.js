"use strict";
exports.__esModule = true;
exports.DroitProduit = void 0;
var DroitProduit = /** @class */ (function () {
    function DroitProduit(droit, produit) {
        this.droit = droit;
        this.produit = produit;
    }
    return DroitProduit;
}());
exports.DroitProduit = DroitProduit;
