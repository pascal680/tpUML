"use strict";
exports.__esModule = true;
exports.Client = void 0;
var Client = /** @class */ (function () {
    function Client() {
        this.idClient = undefined;
        this.type = undefined;
        this.adresse = undefined;
        this.droit = undefined;
    }
    return Client;
}());
exports.Client = Client;
