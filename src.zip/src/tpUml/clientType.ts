import { Entreprise } from "./entreprise";

export enum ClientType {
    Individu = "Individu",
    Entreprise = "Entreprise"
}